<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		html,body{
			height: 100%;
		}
		.container{
			height: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
		}
		.row{
			display: flex;
			flex-direction: row;
			margin-top: 25px;
		}
		.btn_login{
			margin-top: 25px;
		}
		.btn{
			margin-top: 25px;
		}
		hr{
			background: black;
			height: 1px;
			width: 5cm;
		}
	</style>
</head>
<body>
	<?php
	session_start();//khai báo sử dụng session
	header('Content-type: text/html; charset=UTF-8');
	//xứ lý đăng nhập
	if (isset($_POST['login'])) {//handle the form
		//kết nối tới database
		$con = mysqli_connect("localhost","root","","cv");
		if (mysqli_connect_errno()){
		    echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}

		//lấy dl nhập vào
		$username = addslashes($_POST['username']);
		$password = addslashes($_POST['psw']);

		//kiểm tra đã nhập đủ đăng nhập với mật khẩu chưa
		if (!$username || !$password) {
			echo "Vui lòng nhập đầy đủ tt đăng nhập";
			exit;
		}

		//mã hóa pass
		$password = md5($password);

		//kiểm tra tên đăng nhập có tồn tại k
		$query = mysqli_query($con,"SELECT username,password FROM users WHERE username = '$username'");
		if (mysqli_num_rows($query) == 0) {
			# code...
			echo "Tên đăng nhập k tồn tại.Vui lòng kiểm tra lại";
			exit;
		}

		//lấy mk trong database ra
		$row = mysqli_fetch_array($query,MYSQLI_ASSOC);

		//so sánh 2 mk có trùng nhau k
		if ($password != $row['password']) {
			# code...
			echo "Mật khẩu sai.nhập lại";
			exit;
		}

		//lưu tên đăng nhập
		$SESSION['username'] = $username;
		echo "Xin chào".$username;
		die();
	}
?>
	<div class="container">
		<form form action="login.php?do=login" method="post">
			<div class="row">
				<span>Username:</span>
				<input class="text_input" type="text" name="username">
			</div>
			<div class="row">
				<span>Password:</span>
				<input class="text_input" type="password" name="psw">
			</div>
			<input class="btn_login" type="submit" name="login" value="Login">
		</form>
		<div class="row">
			<hr>
			<span>Or</span>
			<hr>
		</div>
		<button class="btn">Sign up</button>
	</div>
</body>
</html>