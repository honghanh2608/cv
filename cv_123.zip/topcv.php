<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="topcv.css">
</head>
<body>
	<?php
		$err = "";
		$visible = false;
		$target_dir = "public/uploads/";
		$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
		// Check if image file is a actual image or fake image
		if (isset($_POST["submit"])) {
		    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		    if ($check !== false) {
		        $uploadOk = 1;
		    } else {
		        $err = "File is not an image.";
		        $uploadOk = 0;
		    }
		}
		if ($_FILES["fileToUpload"]["size"] > 5000000) {
		    $err = "Sorry, your file is too large.";
		    $uploadOk = 0;
		}
		// Allow certain file formats
		if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		    && $imageFileType != "gif") {
		    $err = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
		    $uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		//        $err = "Sorry, your file was not uploaded.";
		    // if everything is ok, try to upload file
		} else {
		    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
		    } else {
		        $err = "Sorry, there was an error uploading your file.";
		    }
		}

		#chuyển dấu cách trong html thành dấu xuống dòng
		function normalstr($str)
		{
			while (strpos($str, "\n")) {
				$str = str_replace("\n", "<br>", $str);
			}
			return $str;
		}
	?>

	<div class="container">
		<div class="basic_container">
			<img class="avatar" src="<?php echo $target_file; ?>">
			<div class="basic_info_container">
				<span class="fullname">
					<?php
					echo $_POST["fullname"];
					?>
				</span>
				<table>
					<tr>
						<td style="width: 200px" class="job">Position want to apply:</td>
						<td class="job">
							<?php
							echo $_POST["pos_job"];
							?>
						</td>
					</tr>
				</table>
				<table class="info">
					<tr>
						<td style="width: 100px;" class="info_n">Birthday:</td>
						<td>
							<?php
							echo date("d-m-Y",strtotime($_POST["birthday"]));
							?>
						</td>
					</tr>
					<tr>
						<td class="info_n">Gender:</td>
						<td>
							<?php
								echo $_POST["gender"];
							?>
						</td>
					</tr>
					<tr>
						<td class="info_n">Address:</td>
						<td>
							<?php
								echo $_POST["address"];
							?>
						</td>
					</tr>
					<tr>
						<td class="info_n">Phone number:</td>
						<td>
							<?php
								echo $_POST["phone"];
							?>
						</td>
					</tr>
					<tr>
						<td class="info_n">Email:</td>
						<td>
							<?php
								echo $_POST["mail"];
							?>
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="field_container">
			<span class="field_n">Education process</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["education"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Working process</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["working"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Society activities</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["society_activities"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Skills</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["skills"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Experiences</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["experiences"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Certifications</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["certifications"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Hobbies</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["hobbies"]);
				?>
			</span>
		</div>
		<div class="field_container">
			<span class="field_n">Desire</span>
			<hr>
			<span>
				<?php
					echo normalstr($_POST["desire"]);
				?>
			</span>
		</div>
	</div>
</body>
</html>